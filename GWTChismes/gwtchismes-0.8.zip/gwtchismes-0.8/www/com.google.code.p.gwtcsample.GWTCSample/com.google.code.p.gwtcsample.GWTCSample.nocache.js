function com_google_code_p_gwtcsample_GWTCSample(){
  var $wnd_0 = window, $doc_0 = document, $stats = $wnd_0.__gwtStatsEvent?function(a){
    return $wnd_0.__gwtStatsEvent(a);
  }
  :null, scriptsDone, loadDone, bodyDone, base = '', metaProps = {}, values = [], providers = [], answers = [], onLoadErrorFunc, propertyErrorFunc;
  $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'bootstrap', millis:(new Date()).getTime(), type:'begin'});
  if (!$wnd_0.__gwt_stylesLoaded) {
    $wnd_0.__gwt_stylesLoaded = {};
  }
  if (!$wnd_0.__gwt_scriptsLoaded) {
    $wnd_0.__gwt_scriptsLoaded = {};
  }
  function isHostedMode(){
    try {
      return $wnd_0.external && ($wnd_0.external.gwtOnLoad && $wnd_0.location.search.indexOf('gwt.hybrid') == -1);
    }
     catch (e) {
      return false;
    }
  }

  function maybeStartModule(){
    if (scriptsDone && loadDone) {
      var iframe = $doc_0.getElementById('com.google.code.p.gwtcsample.GWTCSample');
      var frameWnd = iframe.contentWindow;
      frameWnd.__gwt_initHandlers = com_google_code_p_gwtcsample_GWTCSample.__gwt_initHandlers;
      if (isHostedMode()) {
        frameWnd.__gwt_getProperty = function(name){
          return computePropValue(name);
        }
        ;
      }
      com_google_code_p_gwtcsample_GWTCSample = null;
      frameWnd.gwtOnLoad(onLoadErrorFunc, 'com.google.code.p.gwtcsample.GWTCSample', base);
      $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'moduleStartup', millis:(new Date()).getTime(), type:'end'});
    }
  }

  function computeScriptBase(){
    var thisScript, markerId = '__gwt_marker_com.google.code.p.gwtcsample.GWTCSample', markerScript;
    $doc_0.write('<script id="' + markerId + '"><\/script>');
    markerScript = $doc_0.getElementById(markerId);
    thisScript = markerScript && markerScript.previousSibling;
    while (thisScript && thisScript.tagName != 'SCRIPT') {
      thisScript = thisScript.previousSibling;
    }
    function getDirectoryOfFile(path){
      var hashIndex = path.lastIndexOf('#');
      if (hashIndex == -1) {
        hashIndex = path.length;
      }
      var queryIndex = path.indexOf('?');
      if (queryIndex == -1) {
        queryIndex = path.length;
      }
      var slashIndex = path.lastIndexOf('/', Math.min(queryIndex, hashIndex));
      return slashIndex >= 0?path.substring(0, slashIndex + 1):'';
    }

    ;
    if (thisScript && thisScript.src) {
      base = getDirectoryOfFile(thisScript.src);
    }
    if (base == '') {
      var baseElements = $doc_0.getElementsByTagName('base');
      if (baseElements.length > 0) {
        base = baseElements[baseElements.length - 1].href;
      }
       else {
        base = getDirectoryOfFile($doc_0.location.href);
      }
    }
     else if (base.match(/^\w+:\/\//)) {
    }
     else {
      var img = $doc_0.createElement('img');
      img.src = base + 'clear.cache.gif';
      base = getDirectoryOfFile(img.src);
    }
    if (markerScript) {
      markerScript.parentNode.removeChild(markerScript);
    }
  }

  function processMetas(){
    var metas = document.getElementsByTagName('meta');
    for (var i = 0, n = metas.length; i < n; ++i) {
      var meta = metas[i], name = meta.getAttribute('name'), content;
      if (name) {
        if (name == 'gwt:property') {
          content = meta.getAttribute('content');
          if (content) {
            var value, eq = content.indexOf('=');
            if (eq >= 0) {
              name = content.substring(0, eq);
              value = content.substring(eq + 1);
            }
             else {
              name = content;
              value = '';
            }
            metaProps[name] = value;
          }
        }
         else if (name == 'gwt:onPropertyErrorFn') {
          content = meta.getAttribute('content');
          if (content) {
            try {
              propertyErrorFunc = eval(content);
            }
             catch (e) {
              alert('Bad handler "' + content + '" for "gwt:onPropertyErrorFn"');
            }
          }
        }
         else if (name == 'gwt:onLoadErrorFn') {
          content = meta.getAttribute('content');
          if (content) {
            try {
              onLoadErrorFunc = eval(content);
            }
             catch (e) {
              alert('Bad handler "' + content + '" for "gwt:onLoadErrorFn"');
            }
          }
        }
      }
    }
  }

  function __gwt_isKnownPropertyValue(propName, propValue){
    return propValue in values[propName];
  }

  function __gwt_getMetaProperty(name){
    var value = metaProps[name];
    return value == null?null:value;
  }

  function unflattenKeylistIntoAnswers(propValArray, value){
    var answer = answers;
    for (var i = 0, n = propValArray.length - 1; i < n; ++i) {
      answer = answer[propValArray[i]] || (answer[propValArray[i]] = []);
    }
    answer[propValArray[n]] = value;
  }

  function computePropValue(propName){
    var value = providers[propName](), allowedValuesMap = values[propName];
    if (value in allowedValuesMap) {
      return value;
    }
    var allowedValuesList = [];
    for (var k in allowedValuesMap) {
      allowedValuesList[allowedValuesMap[k]] = k;
    }
    if (propertyErrorFunc) {
      propertyErrorFunc(propName, allowedValuesList, value);
    }
    throw null;
  }

  var frameInjected;
  function maybeInjectFrame(){
    if (!frameInjected) {
      frameInjected = true;
      var iframe = $doc_0.createElement('iframe');
      iframe.src = "javascript:''";
      iframe.id = 'com.google.code.p.gwtcsample.GWTCSample';
      iframe.style.cssText = 'position:absolute;width:0;height:0;border:none';
      iframe.tabIndex = -1;
      $doc_0.body.appendChild(iframe);
      $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'moduleStartup', millis:(new Date()).getTime(), type:'moduleRequested'});
      iframe.contentWindow.location.replace(base + strongName);
    }
  }

  providers['locale'] = function(){
    try {
      var locale;
      if (locale == null) {
        var args = location.search;
        var startLang = args.indexOf('locale');
        if (startLang >= 0) {
          var language = args.substring(startLang);
          var begin = language.indexOf('=') + 1;
          var end = language.indexOf('&');
          if (end == -1) {
            end = language.length;
          }
          locale = language.substring(begin, end);
        }
      }
      if (locale == null) {
        locale = __gwt_getMetaProperty('locale');
      }
      if (locale == null) {
        return 'default';
      }
      while (!__gwt_isKnownPropertyValue('locale', locale)) {
        var lastIndex = locale.lastIndexOf('_');
        if (lastIndex == -1) {
          locale = 'default';
          break;
        }
         else {
          locale = locale.substring(0, lastIndex);
        }
      }
      return locale;
    }
     catch (e) {
      alert('Unexpected exception in locale detection, using default: ' + e);
      return 'default';
    }
  }
  ;
  values['locale'] = {'default':0, en:1, es:2, fr:3, ja:4};
  providers['user.agent'] = function(){
    var ua = navigator.userAgent.toLowerCase();
    var makeVersion = function(result){
      return parseInt(result[1]) * 1000 + parseInt(result[2]);
    }
    ;
    if (ua.indexOf('opera') != -1) {
      return 'opera';
    }
     else if (ua.indexOf('webkit') != -1) {
      return 'safari';
    }
     else if (ua.indexOf('msie') != -1) {
      var result_0 = /msie ([0-9]+)\.([0-9]+)/.exec(ua);
      if (result_0 && result_0.length == 3) {
        if (makeVersion(result_0) >= 6000) {
          return 'ie6';
        }
      }
    }
     else if (ua.indexOf('gecko') != -1) {
      var result_0 = /rv:([0-9]+)\.([0-9]+)/.exec(ua);
      if (result_0 && result_0.length == 3) {
        if (makeVersion(result_0) >= 1008)
          return 'gecko1_8';
      }
      return 'gecko';
    }
    return 'unknown';
  }
  ;
  values['user.agent'] = {gecko:0, gecko1_8:1, ie6:2, opera:3, safari:4};
  com_google_code_p_gwtcsample_GWTCSample.onScriptLoad = function(){
    if (frameInjected) {
      loadDone = true;
      maybeStartModule();
    }
  }
  ;
  com_google_code_p_gwtcsample_GWTCSample.onInjectionDone = function(){
    scriptsDone = true;
    $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'loadExternalRefs', millis:(new Date()).getTime(), type:'end'});
    maybeStartModule();
  }
  ;
  computeScriptBase();
  processMetas();
  $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'bootstrap', millis:(new Date()).getTime(), type:'selectingPermutation'});
  var strongName;
  if (isHostedMode()) {
    strongName = 'hosted.html?com_google_code_p_gwtcsample_GWTCSample';
  }
   else {
    try {
      unflattenKeylistIntoAnswers(['default', 'ie6'], '000C65695957174BBB435113B1EDE9A3.cache.html');
      unflattenKeylistIntoAnswers(['en', 'ie6'], '000C65695957174BBB435113B1EDE9A3.cache.html');
      unflattenKeylistIntoAnswers(['es', 'ie6'], '000C65695957174BBB435113B1EDE9A3.cache.html');
      unflattenKeylistIntoAnswers(['fr', 'ie6'], '000C65695957174BBB435113B1EDE9A3.cache.html');
      unflattenKeylistIntoAnswers(['ja', 'ie6'], '000C65695957174BBB435113B1EDE9A3.cache.html');
      unflattenKeylistIntoAnswers(['default', 'opera'], '0EB3182614392E7BF96528E07A938ECD.cache.html');
      unflattenKeylistIntoAnswers(['en', 'opera'], '0EB3182614392E7BF96528E07A938ECD.cache.html');
      unflattenKeylistIntoAnswers(['es', 'opera'], '0EB3182614392E7BF96528E07A938ECD.cache.html');
      unflattenKeylistIntoAnswers(['fr', 'opera'], '0EB3182614392E7BF96528E07A938ECD.cache.html');
      unflattenKeylistIntoAnswers(['ja', 'opera'], '0EB3182614392E7BF96528E07A938ECD.cache.html');
      unflattenKeylistIntoAnswers(['default', 'gecko1_8'], '30385D94709DE93BACD4DB01A30B7425.cache.html');
      unflattenKeylistIntoAnswers(['en', 'gecko1_8'], '30385D94709DE93BACD4DB01A30B7425.cache.html');
      unflattenKeylistIntoAnswers(['es', 'gecko1_8'], '30385D94709DE93BACD4DB01A30B7425.cache.html');
      unflattenKeylistIntoAnswers(['fr', 'gecko1_8'], '30385D94709DE93BACD4DB01A30B7425.cache.html');
      unflattenKeylistIntoAnswers(['ja', 'gecko1_8'], '30385D94709DE93BACD4DB01A30B7425.cache.html');
      unflattenKeylistIntoAnswers(['default', 'gecko'], 'B06118A59E8C58F9CCEB024CF00668C7.cache.html');
      unflattenKeylistIntoAnswers(['en', 'gecko'], 'B06118A59E8C58F9CCEB024CF00668C7.cache.html');
      unflattenKeylistIntoAnswers(['es', 'gecko'], 'B06118A59E8C58F9CCEB024CF00668C7.cache.html');
      unflattenKeylistIntoAnswers(['fr', 'gecko'], 'B06118A59E8C58F9CCEB024CF00668C7.cache.html');
      unflattenKeylistIntoAnswers(['ja', 'gecko'], 'B06118A59E8C58F9CCEB024CF00668C7.cache.html');
      unflattenKeylistIntoAnswers(['default', 'safari'], '2CC436EF6F2AFB55FA069CA00B43B0A9.cache.html');
      unflattenKeylistIntoAnswers(['en', 'safari'], '2CC436EF6F2AFB55FA069CA00B43B0A9.cache.html');
      unflattenKeylistIntoAnswers(['es', 'safari'], '2CC436EF6F2AFB55FA069CA00B43B0A9.cache.html');
      unflattenKeylistIntoAnswers(['fr', 'safari'], '2CC436EF6F2AFB55FA069CA00B43B0A9.cache.html');
      unflattenKeylistIntoAnswers(['ja', 'safari'], '2CC436EF6F2AFB55FA069CA00B43B0A9.cache.html');
      strongName = answers[computePropValue('locale')][computePropValue('user.agent')];
    }
     catch (e) {
      return;
    }
  }
  var onBodyDoneTimerId;
  function onBodyDone(){
    if (!bodyDone) {
      bodyDone = true;
      maybeStartModule();
      if ($doc_0.removeEventListener) {
        $doc_0.removeEventListener('DOMContentLoaded', onBodyDone, false);
      }
      if (onBodyDoneTimerId) {
        clearInterval(onBodyDoneTimerId);
      }
    }
  }

  if ($doc_0.addEventListener) {
    $doc_0.addEventListener('DOMContentLoaded', function(){
      maybeInjectFrame();
      onBodyDone();
    }
    , false);
  }
  var onBodyDoneTimerId = setInterval(function(){
    if (/loaded|complete/.test($doc_0.readyState)) {
      maybeInjectFrame();
      onBodyDone();
    }
  }
  , 50);
  $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'bootstrap', millis:(new Date()).getTime(), type:'end'});
  $stats && $stats({moduleName:'com.google.code.p.gwtcsample.GWTCSample', subSystem:'startup', evtGroup:'loadExternalRefs', millis:(new Date()).getTime(), type:'begin'});
  $doc_0.write('<script defer="defer">com_google_code_p_gwtcsample_GWTCSample.onInjectionDone(\'com.google.code.p.gwtcsample.GWTCSample\')<\/script>');
}

com_google_code_p_gwtcsample_GWTCSample.__gwt_initHandlers = function(resize, beforeunload, unload){
  var $wnd_0 = window, oldOnResize = $wnd_0.onresize, oldOnBeforeUnload = $wnd_0.onbeforeunload, oldOnUnload = $wnd_0.onunload;
  $wnd_0.onresize = function(evt){
    try {
      resize();
    }
     finally {
      oldOnResize && oldOnResize(evt);
    }
  }
  ;
  $wnd_0.onbeforeunload = function(evt){
    var ret, oldRet;
    try {
      ret = beforeunload();
    }
     finally {
      oldRet = oldOnBeforeUnload && oldOnBeforeUnload(evt);
    }
    if (ret != null) {
      return ret;
    }
    if (oldRet != null) {
      return oldRet;
    }
  }
  ;
  $wnd_0.onunload = function(evt){
    try {
      unload();
    }
     finally {
      oldOnUnload && oldOnUnload(evt);
      $wnd_0.onresize = null;
      $wnd_0.onbeforeunload = null;
      $wnd_0.onunload = null;
    }
  }
  ;
}
;
com_google_code_p_gwtcsample_GWTCSample();
